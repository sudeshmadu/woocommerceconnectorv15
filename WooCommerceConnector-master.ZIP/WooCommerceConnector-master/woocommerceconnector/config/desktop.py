# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _

def get_data():
	return [
		{
			"module_name": "WooCommerceConnector",
			"color": "#9b5c8f",
			"icon": "fa fa-shopping-cart",
			"type": "module",
			"label": _("WooCommerce")
		}
	]
